(() => {
    const hostname = window.location.hostname;
    const isSparxMaths = hostname.includes('maths.sparx-learning.com');
  
    if (!isSparxMaths) {
      console.log("⛔ Not on Sparx Maths Homework. Extension inactive.");
      return;
    }
  
    console.log("🚀 SparxMaths Homework detected! Initializing AI power...");
  
    console.log("Made by Kiyan!")
  
    let cardCounter = 0;
    let cardData = {};
    let studentName;
    let API_KEY = "AIzaSyD3BqxlEmUfvJ3sUGlSwixSzBWBzQ1eFdA" // REPLACE WITH YOUR OWN
  
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('helpers/h2c.js');
    document.head.appendChild(script);
  
    // Configuration: Replace with your actual Gemini endpoint and API key
    const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${API_KEY}`; // Example endpoint
  
    // Inject custom CSS for UI elements: solve button, loading spinner, answer card
    function injectStyles() {
      const style = document.createElement('style');
      style.textContent = `
        /* Solve button styling */
        .solve-btn {
          position: fixed;
          bottom: 20px;
          left: 20px;
          padding: 10px 16px;
          background-color: #4CAF50;
          color: #fff;
          border: none;
          border-radius: 8px;
          font-size: 14px;
          cursor: pointer;
          box-shadow: 0 2px 6px rgba(0,0,0,0.2);
          z-index: 9999;
          transition: background-color 0.3s, transform 0.2s;
        }
        .solve-btn:hover {
          background-color: #45a049;
        }
        .solve-btn:active {
          transform: translateY(2px);
        }
        .solve-btn:disabled {
          background-color: #888;
          cursor: not-allowed;
        }
        /* Loading overlay styling */
        .loading-overlay {
          position: fixed;
          top: 0; left: 0;
          width: 100%; height: 100%;
          background: rgba(0,0,0,0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9998;
        }
        .loading-overlay.hidden {
          display: none;
        }
        .loading-overlay .spinner {
          width: 50px;
          height: 50px;
          border: 6px solid #f3f3f3;
          border-top: 6px solid #4CAF50;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        /* Answer card styling */
        .answer-card {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 380px;
          max-width: 95%;
          padding: 16px 20px;
          background-color: #fff;
          color: #333;
          font-family: Arial, sans-serif;
          font-size: 14px;
          line-height: 1.5;
          border-radius: 10px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 9999;
          animation: fadeIn 0.3s ease-out;
        }
        .answer-card.error {
          border-left: 4px solid #e74c3c;
        }
        .answer-card .close-btn {
          position: absolute;
          top: 8px; right: 10px;
          background: none;
          border: none;
          font-size: 20px;
          color: #888;
          cursor: pointer;
        }
        .answer-card .close-btn:hover {
          color: #444;
        }
        .answer-content {
          white-space: pre-wrap;
          max-height: 300px;
          overflow-y: auto;
          margin-top: 10px;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
      `;
      document.head.appendChild(style);
    }
  
    // Create and insert the "Solve with AI" button into the page
    function createSolveButton() {
      if (document.querySelector('.solve-btn')) return; // avoid duplicates
      const btn = document.createElement('button');
      btn.textContent = 'Solve with AI';
      btn.className = 'solve-btn';
      btn.id = 'solveButton';
      btn.addEventListener('click', onSolveButtonClick);
      document.body.appendChild(btn);
    }
  
    // Show a full-screen loading overlay with a CSS spinner
    function showLoadingOverlay() {
      let overlay = document.querySelector('.loading-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.className = 'loading-overlay';
        const spinner = document.createElement('div');
        spinner.className = 'spinner';
        overlay.appendChild(spinner);
        document.body.appendChild(overlay);
      }
      overlay.classList.remove('hidden');
    }
  
    // Hide the loading overlay
    function hideLoadingOverlay() {
      const overlay = document.querySelector('.loading-overlay');
      if (overlay) {
        overlay.classList.add('hidden');
      }
    }
  
    // Create or update the answer card UI with the given text
    // If isError is true, style the card as an error
    function showAnswerCard(text, isError = false) {
      // Remove existing card if present
      let card = document.querySelector('.answer-card');
      if (card) {
        card.remove();
      }
      // Create card container
      card = document.createElement('div');
      card.className = 'answer-card';
      if (isError) {
        card.classList.add('error');
      }
      // Close button (×)
      const closeBtn = document.createElement('button');
      closeBtn.className = 'close-btn';
      closeBtn.innerHTML = '&times;';
      closeBtn.title = 'Close';
      closeBtn.addEventListener('click', () => {
        card.remove();
      });
      // Answer content area
      const content = document.createElement('div');
      content.className = 'answer-content';
      content.textContent = text || 'No answer available.';
      card.appendChild(closeBtn);
      card.appendChild(content);
      document.body.appendChild(card);
    }
  
    // Capture a screenshot of the question element using html2canvas
    async function captureQuestionScreenshot() {
      // Identify the question element on the page (selector may vary)
      let questionElement = document.querySelector('.question-content, .problem-statement, #work_area')
                           || document.querySelector('#main')
                           || document.body;
      // Scroll question into view for accuracy
      questionElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Capture with html2canvas (adjust options for performance/quality tradeoff)
      const canvas = await html2canvas(questionElement, {
        scale: 1,
        useCORS: true,
        allowTaint: false,
        logging: false
      });
      // Convert canvas to a Blob object (PNG)
      return new Promise((resolve) => {
        canvas.toBlob(blob => resolve(blob), 'image/png');
      });
    }
  
    // Send the image to Gemini API and return the answer text
    async function callGeminiAPI(imageBlob) {
        try {
          // Build form data with image and prompt
          const formData = new FormData();
          formData.append('image', imageBlob, 'question.png');
          formData.append('prompt', 'Solve the math problem shown in this image and provide the answer.');
      
          const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${API_KEY}`,
              // Removed Content-Type header
            },
            body: formData,
          });
          if (!response.ok) {
            // Parse error response if available
            const errorData = await response.text();
            throw new Error(`API request failed: ${errorData || response.status}`);
          }
          const data = await response.json();
          // Extract answer from response (adjust to actual API's response structure)
          if (data.answer) {
            return data.answer;
          } else if (data.answers) {
            // Join multiple answers if array
            return Array.isArray(data.answers) ? data.answers.join('\n') : data.answers;
          } else {
            // Fallback to raw JSON if structure is unknown
            return JSON.stringify(data);
          }
        } catch (err) {
          console.error('Error calling Gemini API:', err);
          throw err;
        }
      }
      
  
    // Handler for Solve button click event
    async function onSolveButtonClick() {
      const solveBtn = document.querySelector('#solveButton');
      if (!solveBtn) return;
      solveBtn.disabled = true; // prevent multiple clicks
      showLoadingOverlay();
      try {
        // Capture screenshot of question
        const imageBlob = await captureQuestionScreenshot();
        // Call Gemini and get answer text
        const answerText = await callGeminiAPI(imageBlob);
        hideLoadingOverlay();
        // Display answer in card
        showAnswerCard(answerText, false);
      } catch (error) {
        console.error('Error in solve process:', error);
        hideLoadingOverlay();
        showAnswerCard('Error retrieving answer. Please try again.', true);
      } finally {
        solveBtn.disabled = false;
      }
    }
  
    // Initialize the extension (inject styles, button, and mutation observer)
    function init() {
      injectStyles();
      createSolveButton();
      // Observe DOM in case question content dynamically changes (re-add button if removed)
      const observer = new MutationObserver(() => {
        if (!document.querySelector('#solveButton')) {
          createSolveButton();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  
    // Run init when document is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  
3})();