chrome.action.onClicked.addListener((tab) => {
  const url = tab.url;

  if (!url) return; // Safety first! No URL, no fun.

  if (url.includes("sparxmaths.uk") || url.includes("maths.sparx-learning.com")) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['maths/sparxmaths.js', 'maths/deps/h2c.js', 'maths/deps/helpers.js', 'maths/inject.js', 'maths/popupLogic.js']
    });

    chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ['maths/styles.css', 'maths/sparxmaths.css']
    });
  } else if (url.includes("app.sparxreader.com") || url.includes("sparxreader.com") || url.includes("reader.sparx-learning.com")) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['reader/inject.js', 'reader/popupLogic.js', 'reader/nameSrpUi.js', 'reader/reader.js', 'reader/vocab.js']
    });

    chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ['reader/styles.css']
    });
  } else {
    console.log("No matching site detected, no injection for you!");
  }
});

  