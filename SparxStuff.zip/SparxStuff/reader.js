console.log("Sparx Reader Script loaded!");

const API_KEY = "AIzaSyBzXWmYj9yEKlTmEX-838RePQ6U6H49bEU";

let copiedText = '';
let lastEnterPress = 0;
let autoAnswerCount = 0;

setInterval(() => {
  const url = window.location.href;
  if (url.includes('/library') || url.includes('/task')) {
    ['next', 'continue', 'retry', 'start', 'continue reading', 'keep trying', 'yes, ask me the questions.'].forEach(buttonText => clickButton(buttonText));
  }
}, 200);

const beginButton = document.getElementById('manualWrapper');

if (beginButton) {
  beginButton.addEventListener('click', () => {

    checkForQs()
  });
}

let autoAnswerCallCount = 0; // 🧠 Stays outside to persist across calls

let answerLoopInterval = null;
let wasQuestionVisible = false; // To track whether the question was visible previously
let cachedText = null;
let isAnswering = false; // To track if answering is in progress

function questionAndOptionsExist() {

  const questionDiv = Array.from(document.querySelectorAll('h2 > div')).find(div => {
    const text = div.innerText.trim();
    return (text.includes('?') || text.includes('.')) && text.length < 500;
  });

  const optionButtons = Array.from(document.querySelectorAll('button')).filter(button => {
    const text = button.querySelector('div')?.textContent.trim();
    const badTexts = ["Settings", "Feedback", "Cookie Settings", "Sign out", "I have read up to here"];
    return text && !badTexts.includes(text);
  });

  return questionDiv && optionButtons.length >= 2;
}

// 🧠 Fetch contentDiv text and store it in cache
function fetchReadingContext() {
  const candidates = Array.from(document.querySelectorAll('div')).filter(div =>
    div.textContent.includes('Start reading here')
  );

  let bestDiv = null;
  let maxParagraphs = 0;

  candidates.forEach(div => {
    const paragraphs = div.querySelectorAll('p');
    if (paragraphs.length > maxParagraphs) {
      maxParagraphs = paragraphs.length;
      bestDiv = div;
    }
  });

  cachedText = bestDiv
    ? Array.from(bestDiv.querySelectorAll('p')).map(p => p.textContent.trim()).join(' ')
    : null;

  console.log("📚 Cached text updated:", cachedText);
}

async function autoAnswer() {

  // Proceed with the normal question answering
  const questionData = extractQuestionAndOptions();
  if (!questionData) {
    console.log("❌ Could not extract question/options.");
    return;
  }

  const { question, options, optionElements } = questionData;

  if (!cachedText) {
    console.log("📭 No cached reading text!");
    return;
  }

  console.log("❓ Question:", question);
  console.log("🔘 Options:", options);

  const answer = await queryGemini(question, options, cachedText);
  bottomText.innerText = answer;
  if (!answer) {
    console.log("🤷 Gemini returned nothing.");
    return;
  }

  const matchIndex = options.findIndex(opt =>
    opt.toLowerCase().includes(answer.toLowerCase())
  );

  if (matchIndex !== -1) {
    optionElements[matchIndex].click();
    console.log(`✅ Clicked: ${options[matchIndex]}`);
  } else {
    console.log("🤷‍♂️ No option matched.");
  }
}

// 👀 Watch for the question visibility and manage caching
function monitorQuestion() {
  let wasQuestionVisible = false;

  setInterval(() => {
    const isVisible = questionAndOptionsExist();

    if (isVisible && !wasQuestionVisible) {
      // If question and options are visible, update flag and cache content if necessary
      console.log("🟢 Question and options found! Proceeding with the auto-answering loop.");
      if (!cachedText) {
        fetchReadingContext();
      }
      wasQuestionVisible = true;
    }

    if (!isVisible && wasQuestionVisible) {
      // If question and options are no longer visible, stop auto-answering and clear cache
      console.log("🔴 Question and options no longer visible. Stopping the loop.");
      wasQuestionVisible = false;
    }
  }, 1000); // Check every second
}

// 🤖 Auto answer logic
async function checkForQs() {
  // Check if the question and options exist before processing
  if (!questionAndOptionsExist()) {
    // If the questions/options are not visible, fetch the content text
      console.log("📖 Question and options not found, fetching reading context...");
      fetchReadingContext();
  }

  clickButton('i have read up to here');

    let intervalId = setInterval(() => {
      if (questionAndOptionsExist()) {
      autoAnswer();
      } else {
      clearInterval(intervalId);
      console.log("Questions and options disappeared. Stopping auto-answer attempts.");
      }
    }, 2000);
}

// 🚀 INIT
monitorQuestion();

function extractQuestionAndOptions() {
  const questionElement = Array.from(document.querySelectorAll('h2 > div')).find(div => {
    const text = div.innerText.trim();
    const isShortEnough = text.length < 500; // You can tweak this!
    const hasPunctuation = text.includes('?') || text.includes('.');
    return hasPunctuation && isShortEnough;
  });

  if (!questionElement) {
    console.warn("⚠️ No question element found!");
    return null;
  }

  const badTexts = ["Settings", "Feedback", "Cookie Settings", "Sign out", "I have read up to here"];
  const optionElements = Array.from(document.querySelectorAll('button')).filter(button => {
    const text = button.querySelector('div')?.textContent.trim();
    return text && !badTexts.includes(text);
  });

  const question = questionElement.innerText.trim();
  const options = optionElements.map(option => option.innerText.trim());

  return { question, options, optionElements };
}

// Unified button click function
const clickButton = (buttonText) => {
  const button = [...document.querySelectorAll('button')].find(btn => btn.textContent.trim().toLowerCase() === buttonText);
  if (button) {
    button.click();
    return true;
  }
  return false;
};

setInterval(() => {
  const url = window.location.href;
  if (url.includes('/library') || url.includes('/task')) {
    ['next', 'continue', 'retry', 'start'].forEach(buttonText => clickButton(buttonText));
  }

  if ((url.includes('/task') && clickButton('continue reading')) || (url.includes('/task') && clickButton('retry'))) {
    if (autoKeypressEnabled) {
      setTimeout(() => {
        document.dispatchEvent(new KeyboardEvent('keydown', {
          key: '1', code: 'Digit1', which: 49, keyCode: 49, bubbles: true, cancelable: true
        }));
        console.log("Simulated '1' key press");
      }, 5000);
    }
  } else if (url.includes('/library')) {
    clickButton('continue reading');
  }
}, 200);

// Extract text and click first button
async function getToQuestions() {
  const allDivs = Array.from(document.querySelectorAll('div'));

const contentDiv = allDivs.find(div => {
  const style = window.getComputedStyle(div);
  const bgColor = style.backgroundColor;
  return bgColor.includes('blue') || bgColor === 'rgb(203, 232, 239)'; // catching named and RGB blues
});
  
  if (!contentDiv) {
    console.log("Couldn't find the content div");
    return;
  }

  copiedText = Array.from(contentDiv.querySelectorAll('p')).map(p => p.textContent.trim()).join(' ');
  console.log("Extracted text:", copiedText);

  if (copiedText.trim() !== "") {
    const button1 = document.querySelector('[data-test-id="read-button"]');
    if (button1) {
      button1.click();
      console.log("Clicked the first button!");
      const interval = setInterval(() => {
        if (clickButton('yes, ask me the questions.')) {
          clearInterval(interval);
          startAutoAnswerLoop();
        } else {
          console.log("Couldn’t find the 'yes, ask me the questions.' button...");
          clearInterval(interval);
          startAutoAnswerLoop();
        }
      }, 500);
    } else {
      console.log("Couldn’t find the first button...");
      startAutoAnswerLoop();
    }
  } else {
    console.log("No text found in the content div.");
  }
}

// Event listeners
document.addEventListener('keydown', async (event) => {
  if (event.key === 'Enter' && !['INPUT', 'TEXTAREA'].includes(event.target.tagName)) {
    const now = Date.now();
    if (now - lastEnterPress < 1000) return;
    lastEnterPress = now;
    event.preventDefault();
    console.log("Enter key pressed. Time to auto-answer!");
    await autoAnswer();
  } 
  
  if (event.key === '1' && window.location.href.includes('https://reader.sparx-learning.com/task')) {
    event.preventDefault();
    autoKeypressEnabled = true;
    await getToQuestions();
  }
});

document.addEventListener('copy', () => {
  copiedText = window.getSelection().toString().trim();
  console.log('Text copied:', copiedText);
});

// Auto-answer loop
function startAutoAnswerLoop() {
  let count = 0;
  const runAutoAnswerRepeatedly = () => {
    if (count < 4) {
      setTimeout(() => {
        console.log(`Auto-answer attempt ${count + 1}...`);
        autoAnswer();
        count++;
        runAutoAnswerRepeatedly();
      }, 2000);
    } else if (document.querySelectorAll('div')[39].innerText.trim().includes('?') || document.querySelectorAll('div')[39].innerText.trim().includes('.')) {
      autoAnswer();
    } else {
      console.log("No more questions to answer.");
    }
  };
  runAutoAnswerRepeatedly();
}

// Query Gemini API
async function queryGemini(question, options, context) {
  const prompt = `You are given the following context and question. Select the single most relevant answer from the provided options. Do not generate anything outside of the specified options. Do not explain. Return exactly one answer string. Context: ${context} Question: ${question} Options: ${options.join(', ')} Respond with only one of the exact options listed above. Answer:`;
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-lite:generateContent?key=${API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ "contents": [{ "parts": [{ "text": prompt }] }] })
    });

    if (!response.ok) {
      console.error("Gemini API Error:", response.statusText);
      return null;
    }

    const data = await response.json();
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    console.log("Gemini Response:", data);
    return answer || "No answer found";

  } catch (error) {
    console.error("Gemini API Fetch Error:", error);
    return null;
  }
}