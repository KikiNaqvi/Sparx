if (!document.getElementById('sparx-cheat-popup')) {
    const style = document.createElement('style');
    style.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=JetBrains+Mono&display=swap');
      #sparx-cheat-popup * {
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
      }
      #sparx-cheat-popup {
        position: fixed;
        top: 20px;
        right: 20px;
        width: 280px;
        background: linear-gradient(180deg, #1e3a8a, #1e40af, #3b82f6);
        border-radius: 20px;
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.5);
        color: #e0f2fe;
        z-index: 999999;
        overflow: hidden;
        font-size: 14px;
      }
      #popupHeader {
        background: rgba(0, 0, 0, 0.2);
        padding: 10px 15px;
        cursor: move;
        font-weight: 600;
        text-align: center;
        color: #ffffff;
        user-select: none;
        text-shadow: 0 0 6px #60a5fa;
        position: relative;
      }
      .window-controls {
        position: absolute;
        top: 6px;
        right: 10px;
        display: flex;
        gap: 6px;
      }
      .window-controls span {
        font-size: 16px;
        font-weight: bold;
        color: #93c5fd;
        background: rgba(255, 255, 255, 0.1);
        padding: 2px 8px;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
        user-select: none;
      }
      .window-controls span:hover {
        background: rgba(255, 255, 255, 0.2);
        color: white;
        transform: scale(1.1);
      }
      #popupContent {
        padding: 15px;
      }
      .button-wrapper {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .cheat-btn {
        background: linear-gradient(to right, #38bdf8, #60a5fa);
        border: none;
        padding: 10px;
        border-radius: 12px;
        color: #0c0c0c;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 0 10px rgba(147, 197, 253, 0.4);
      }
      .cheat-btn:hover {
        transform: scale(1.06);
        background: linear-gradient(to right, #60a5fa, #93c5fd);
        box-shadow: 0 0 15px rgba(147, 197, 253, 0.5);
      }
      #sliderWrapper, #manualWrapper {
        margin-top: 12px;
        display: none;
      }
      #sliderWrapper label {
        display: block;
        margin-bottom: 5px;
      }
      #speedSlider {
        width: 100%;
        accent-color: #38bdf8;
      }
      #bottomText {
        margin-top: 14px;
        background: rgba(0, 0, 0, 0.3);
        border-radius: 8px;
        padding: 8px;
        font-family: 'JetBrains Mono', monospace;
        font-size: 12px;
        color: #cbd5e1;
        word-break: break-word;
      }
      #particles {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0; left: 0;
        overflow: hidden;
        pointer-events: none;
        z-index: 0;
      }
      .particle {
        position: absolute;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        width: 4px;
        height: 4px;
        animation: floatUp 5s linear infinite;
      }
      @keyframes floatUp {
        0% { transform: translateY(100%); opacity: 0.2; }
        100% { transform: translateY(-100%) scale(1.3); opacity: 0; }
      }
    `;
    document.head.appendChild(style);
  
    const wrapper = document.createElement('div');
    wrapper.id = 'sparx-cheat-popup';
    wrapper.innerHTML = `
      <div id="popup">
        <div id="popupHeader">
          Sparx Reader Cheat
          <div class="window-controls">
            <span id="minBtn">–</span>
            <span id="closeBtn">×</span>
          </div>
        </div>
        <div id="particles"></div>
        <div id="popupContent">
          <div class="button-wrapper">
            <button class="cheat-btn" id="autoBtn">Automatic</button>
            <button class="cheat-btn" id="manualBtn">Manual</button>
          </div>
          <div id="sliderWrapper">
            <label>Speed: <span id="sliderValue">1.5</span>s</label>
            <input type="range" id="speedSlider" min="1.5" max="60" step="0.5" value="1.5">
          </div>
          <div id="manualWrapper">
            <button class="cheat-btn">Begin Questions</button>
          </div>
          <div id="bottomText">Answer comes here</div>
        </div>
      </div>
    `;
    document.body.appendChild(wrapper);
  
    // Logic
    const autoBtn = document.getElementById('autoBtn');
    const manualBtn = document.getElementById('manualBtn');
    const sliderWrapper = document.getElementById('sliderWrapper');
    const manualWrapper = document.getElementById('manualWrapper');
    const slider = document.getElementById('speedSlider');
    const sliderValue = document.getElementById('sliderValue');
    const bottomText = document.getElementById('bottomText');
    const popup = document.getElementById("popup");
    const popupHeader = document.getElementById("popupHeader");
    const popupContent = document.getElementById("popupContent");
    const particles = document.getElementById("particles");
    const closeBtn = document.getElementById("closeBtn");
    const minBtn = document.getElementById("minBtn");
  
    let isDragging = false;
    let offsetX, offsetY;
    let isMinimized = false;
  
    autoBtn.addEventListener('click', () => {
      autoBtn.classList.add('active');
      manualBtn.classList.remove('active');
      sliderWrapper.style.display = 'block';
      manualWrapper.style.display = 'none';
      bottomText.innerText = "Answer comes here";
    });
  
    manualBtn.addEventListener('click', () => {
      manualBtn.classList.add('active');
      autoBtn.classList.remove('active');
      sliderWrapper.style.display = 'none';
      manualWrapper.style.display = 'block';
      bottomText.innerText = "Answer comes here";
    });
  
    slider.addEventListener('input', () => {
      sliderValue.textContent = slider.value;
    });
  
    closeBtn.addEventListener('click', () => {
      wrapper.remove();
    });
  
    minBtn.addEventListener('click', () => {
      isMinimized = !isMinimized;
      popupContent.style.display = isMinimized ? 'none' : 'block';
      particles.style.display = isMinimized ? 'none' : 'block';
    });
  
    popupHeader.addEventListener("mousedown", (e) => {
      if (e.target.closest('.window-controls')) return;
      isDragging = true;
      offsetX = e.clientX - wrapper.offsetLeft;
      offsetY = e.clientY - wrapper.offsetTop;
    });
  
    document.addEventListener("mousemove", (e) => {
      if (isDragging) {
        wrapper.style.left = `${e.clientX - offsetX}px`;
        wrapper.style.top = `${e.clientY - offsetY}px`;
      }
    });
  
    document.addEventListener("mouseup", () => {
      isDragging = false;
    });
  
    // Particles
    for (let i = 0; i < 15; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      p.style.left = `${Math.random() * 100}%`;
      p.style.animationDuration = `${4 + Math.random() * 2}s`;
      p.style.opacity = Math.random();
      particles.appendChild(p);
    }
  }
  